import {Capacitor} from '@capacitor/core';
import {App} from '@capacitor/app';
import {Share} from '@capacitor/share';
import {Browser} from '@capacitor/browser';
const onPage=location.pathname.includes('/pages/');const base=onPage?'../':'';
const nav=document.createElement('nav');nav.className='mobile-nav';nav.setAttribute('aria-label','التنقل في التطبيق');
for(const [label,url] of [['الرئيسية','index.html'],['الفحص','pages/bulk-tools.html'],['التدريب','index.html#train'],['الرصد','pages/threat-feed.html'],['الخصوصية','pages/privacy.html']]){const a=document.createElement('a');a.textContent=label;a.href=base+url;nav.append(a);}
document.body.append(nav);
const bar=document.createElement('div');bar.className='mobile-utilities';
const status=document.createElement('span');status.setAttribute('role','status');
const updateNetwork=()=>{status.textContent=navigator.onLine?'متصل — قد تتوفر تحديثات للقوائم':'دون اتصال — أدوات التدريب والفحص المحلي متاحة';};
updateNetwork();addEventListener('online',updateNetwork);addEventListener('offline',updateNetwork);
const share=document.createElement('button');share.type='button';share.textContent='مشاركة نتيجة الفحص';
share.addEventListener('click',async()=>{const result=document.querySelector('#verdict:not([hidden])')||document.querySelector('#results:not([hidden])');const text=result?.innerText?.trim();if(!text){status.textContent='أجرِ فحصًا أولًا، ثم شارك نتيجته.';return;}try{await Share.share({title:'نتيجة فحص وقاية',text:text.slice(0,6000)+'\nالفحص استدلالي ولا يضمن سلامة الرابط.'});}catch{status.textContent='لم تتم مشاركة النتيجة.';}});
bar.append(status,share);document.body.prepend(bar);
document.addEventListener('click',async event=>{const a=event.target.closest('a[href]');if(!a)return;let u;try{u=new URL(a.href)}catch{return;}if(u.origin===location.origin)return;event.preventDefault();if(u.protocol==='https:'){await Browser.open({url:u.href});}});
if(Capacitor.isNativePlatform()){
 await App.addListener('backButton',({canGoBack})=>{if(canGoBack)history.back();else if(onPage)location.href=base+'index.html';else App.minimizeApp();});
}
