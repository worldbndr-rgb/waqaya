import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {JSDOM} from 'jsdom';
const html=await readFile(new URL('../www/index.html',import.meta.url),'utf8');
const dom=new JSDOM(html,{url:'https://localhost/index.html'});
globalThis.window=dom.window;globalThis.document=dom.window.document;globalThis.location=dom.window.location;globalThis.history=dom.window.history;
Object.defineProperty(globalThis,'navigator',{value:dom.window.navigator,configurable:true});globalThis.addEventListener=dom.window.addEventListener.bind(dom.window);
await import('../www/js/native.js');
assert.equal(document.querySelectorAll('.mobile-nav a').length,5);
assert.ok(document.querySelector('.mobile-utilities [role=status]').textContent);
assert.ok(!document.querySelector('.mobile-nav').innerHTML.includes('http:'));
const button=document.querySelector('.mobile-utilities button');button.click();await new Promise(r=>setTimeout(r,0));
assert.match(document.querySelector('.mobile-utilities [role=status]').textContent,/أجرِ فحصًا/);
const cloud=await readFile(new URL('../www/js/cloud-config.js',import.meta.url),'utf8');assert.match(cloud,/enabled:false/);
const data=JSON.parse(await readFile(new URL('../www/data/threats.json',import.meta.url),'utf8'));assert.ok(data.lists.length>=2);
const snapshot=await readFile(new URL('../www/js/scheduled-feed.js',import.meta.url),'utf8');assert.ok(snapshot.includes('https://raw.githubusercontent.com/worldbndr-rgb/waqaya/main/site/data/threats.json'));assert.ok(snapshot.includes("catch{response=await fetch(new URL('../data/threats.json',import.meta.url))"));
for(const name of await readdir(new URL('../www/pages/',import.meta.url))){if(name.endsWith('.html')){const h=await readFile(new URL('../www/pages/'+name,import.meta.url),'utf8');assert.ok(h.includes('../js/native.js'),name);}}
console.log('PASS: navigation, empty-share handling, local privacy settings, bundled snapshot, remote/local fallback, all page integrations');dom.window.close();
