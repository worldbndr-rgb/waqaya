import {cp,readFile,writeFile,mkdir,readdir,rm} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {build} from 'esbuild';
const root=fileURLToPath(new URL('../',import.meta.url));
const out=path.join(root,'www');
await rm(out,{recursive:true,force:true});await mkdir(out,{recursive:true});
for(const name of ['index.html','css','js','pages','data'])await cp(path.join(root,'../site',name),path.join(out,name),{recursive:true});
const bundledSnapshot=JSON.parse(await readFile(path.join(root,'data/threats.json'),'utf8'));
const siteSnapshot=JSON.parse(await readFile(path.join(out,'data/threats.json'),'utf8'));
if(!siteSnapshot.lists?.length) await writeFile(path.join(out,'data/threats.json'),JSON.stringify(bundledSnapshot));
await writeFile(path.join(out,'js/cloud-config.js'),'window.PP_CLOUD={enabled:false,localApi:false};');
await writeFile(path.join(out,'js/ai-config.js'),'export const AI_CONFIG={pollinations:{enabled:false},geminiProxy:{enabled:false},timeoutMs:10000,maxRefreshPerDay:0};');
let scheduled=await readFile(path.join(out,'js/scheduled-feed.js'),'utf8');
scheduled=scheduled.replace("const response=await fetch(new URL('../data/threats.json', import.meta.url),", "let response; try {response=await fetch('https://raw.githubusercontent.com/worldbndr-rgb/waqaya/main/site/data/threats.json',");
scheduled=scheduled.replace("signal:controller.signal});", "signal:controller.signal});if(!response.ok)throw new Error('remote unavailable');}catch{response=await fetch(new URL('../data/threats.json',import.meta.url));}");
await writeFile(path.join(out,'js/scheduled-feed.js'),scheduled);
let safe=await readFile(path.join(out,'pages/safe-browsing.html'),'utf8');
safe=safe.replace("location.hostname.endsWith('.github.io')","true");await writeFile(path.join(out,'pages/safe-browsing.html'),safe);
await cp(path.join(root,'privacy.html'),path.join(out,'pages/privacy.html'));
await cp(path.join(root,'mobile.css'),path.join(out,'css/mobile.css'));
await build({entryPoints:[path.join(root,'native.mjs')],outfile:path.join(out,'js/native.js'),bundle:true,format:'esm',target:'es2022'});
for(const [dir,prefix] of [[out,''],[path.join(out,'pages'),'../']]){
 for(const name of await readdir(dir)){if(!name.endsWith('.html'))continue;
 const p=path.join(dir,name);let html=await readFile(p,'utf8');
 html=html.replace(/content="width=device-width,\s*initial-scale=1"/g,'content="width=device-width,initial-scale=1,viewport-fit=cover"').replace('</head>',`<link rel="stylesheet" href="${prefix}css/mobile.css"></head>`).replace(/<\/body>(?![\s\S]*<\/body>)/,`<script type="module" src="${prefix}js/native.js"></script></body>`);
 await writeFile(p,html);
 }
}
console.log('Built bundled mobile app with local training, privacy and native controls');
