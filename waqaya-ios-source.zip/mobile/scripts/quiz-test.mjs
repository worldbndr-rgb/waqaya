import assert from 'node:assert/strict';import {readFile} from 'node:fs/promises';import {JSDOM} from 'jsdom';
const dom=new JSDOM('<div id="quiz"></div>',{url:'https://localhost'});for(const k of ['window','document','localStorage','navigator'])Object.defineProperty(globalThis,k,{value:dom.window[k],configurable:true});
globalThis.Event=dom.window.Event;dom.window.HTMLElement.prototype.scrollIntoView=function(){};window.PP_CLOUD={enabled:false};
const {Store}=await import('../../site/js/storage.js');const {QUESTIONS}=await import('../../site/js/quiz-data.js');const {shuffle}=await import('../../site/js/analyzers.js');
globalThis.quizDeps={Store,QUESTIONS,shuffle};
const source=await readFile(new URL('../../site/js/app.js',import.meta.url),'utf8');const start=source.indexOf('function initQuiz()');const end=source.indexOf('function initChecklist()',start);
const section=source.slice(start,end);const prelude="const {Store,QUESTIONS,shuffle}=globalThis.quizDeps; const $=(s,r=document)=>r.querySelector(s);const $$=(s,r=document)=>[...r.querySelectorAll(s)];";
await import('data:text/javascript;base64,'+Buffer.from(prelude+section+'\ninitQuiz();').toString('base64'));
function round(correct){for(let i=0;i<10;i++){const q=QUESTIONS.find(q=>{const x=document.createElement('div');x.innerHTML=q.q;return x.textContent===document.querySelector('#q-text').textContent});assert.ok(q);const holder=document.createElement('div');holder.innerHTML=q.options[q.answer];const options=[...document.querySelectorAll('.q-opt')];const button=options.find(b=>correct?b.textContent===holder.textContent:b.textContent!==holder.textContent);button.click();button.click();document.querySelector('#q-next').click();}}
round(true);assert.equal(Store.getQuiz().length,1);assert.equal(Store.getQuiz()[0].pct,100);assert.match(document.querySelector('.quiz-comparison').textContent,/نقطة البداية/);
document.querySelector('#q-again').click();round(false);assert.equal(Store.getQuiz().length,2);assert.match(document.querySelector('.quiz-comparison').textContent,/-100/);assert.equal(Store.getQuiz()[1].pct,0);
console.log('PASS: complete rounds, double-answer protection, first baseline, comparison and stored scores');dom.window.close();
